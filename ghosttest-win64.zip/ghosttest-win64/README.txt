Very rough prototype.

Right hand (one with laser) is a gun. Trigger to shoot.

Left hand controls ghost-teleport. Put thumb on pad to
move ghost around, release to teleport. No need to press any button.

There is no damage, so the big monster can't hurt you.
But try to shoot it down while dodging it.
